function out = get_glob_par()
global par
out = par;
end