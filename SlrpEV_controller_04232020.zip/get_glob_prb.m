function out = get_glob_prb()
global prb
out = prb;
end